<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\http\RequestInterface;
use CodeIgniter\http\ResponseInterface;

class IpWhitelist implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        //allowed ips
        $whitelistedips = [
            '192.168.1.1',
            '203.10.2.12',
            '127.0.0.1',
            '::1'
        ];

        //check client ip and look for match in array
        $clientip = $request->getIPAddress();

        if (!in_array($clientip, $whitelistedips)) {
            return \Config\Services::response()->setStatusCode(403)->setBody('Access Denied');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        //
    }
}