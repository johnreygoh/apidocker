<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->group('user', ['filter' => 'ipwhitelist'], function ($routes) {
    $routes->post('create', 'UserServiceController::createUser');
    $routes->get('(:num)', 'UserServiceController::getUser/$1');
});