<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;


class UserServiceController extends ResourceController
{
    protected $modelName = 'App\Models\UserModel';
    protected $format = 'json';

    // POST http://localhost:8081/user/create
    public function createUser()
    {
        $data = $this->request->getPost();
        if ($this->model->insert($data)) {
            return $this->respondCreated(['status' => 'user created successfully']);
        } else {
            return $this->failValidationErrors($this->model->errors());
        }
    }

    // GET http://localhost:8081/user/1
    public function getUser($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        } else {
            return $this->failNotFound('User not found');
        }
    }



    public function index()
    {
        //
    }

    public function show($id = null)
    {
        //
    }

    public function new()
    {
        //
    }


    public function create()
    {
        //
    }

    public function edit($id = null)
    {
        //
    }


    public function update($id = null)
    {
        //
    }


    public function delete($id = null)
    {
        //
    }
}