<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();

        if ($db->connect()) {
            echo "Database connection ok";
        } else {
            echo "Unable to connect";
        }
    }
}