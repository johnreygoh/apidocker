<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }

    public function test1()
    {
        return "this is test 1";
    }

    public function test2()
    {
        return "this is test 2";
    }

    public function netpay($msal, $deduct)
    {
        $np = $msal - $deduct;
        return "your netpay is $np";
    }

    public function findme($dept, $name)
    {
        return "welcome to $dept, $name!";
    }
}