<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Demo extends BaseController
{
    public function index()
    {
        return view('demo/index');
    }

    public function page1()
    {
        return view('demo/page1');
    }

    public function page2()
    {
        return view('demo/page2');
    }

    public function myregister()
    {
        return view('demo/register');
    }

    public function myprocess()
    {
        // $pname = $this->request->getPost("pname");
        // $pdesc = $this->request->getPost("pdescription");
        // $pprice = $this->request->getPost("pprice");

        // $data["pn"] = $this->request->getPost("pname");
        // $data["pd"] = $this->request->getPost("pdescription");
        // $data["pp"] = $this->request->getPost("pprice");

        $data = $this->request->getPost();

        // process values (model, SQL, compute)

        // pass the value(s) to the view
        return view('demo/process', ['data' => $data]);
    }
}