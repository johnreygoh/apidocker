<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;
use App\Models\ProductModel;
use \Config\Database;

class Product extends ResourceController
{

    public function index()
    {
        // $model = new ProductModel();
        // $data['products'] = $model->findAll();
        // // return var_dump($data);
        // return view('products/index', ['products' => $data['products']]);
        $db = Database::connect();
        $sql = "select * from products";
        $query = $db->query($sql);
        // $result = $data->getResult(); //"1","2"
        $result = $query->getResultArray(); //"id","name"
        // return var_dump($result);
        return view('products/index', ['products' => $result]);
    }

    public function show($id = null)
    {
        $model = new ProductModel();
        // $data['product'] = $model->find($id);
        // $data['product'] = $model
        //     ->where('name','C')
        //     ->orLike('description','wood')
        //     ->orderBy('price')
        //     ->findAll();

        // return view('products/search', ['product' => $data['product']]);
        $db = Database::connect();
        $sql = "Select * from products where id = :id:";
        $query = $db->query($sql, ['id' => $id]);
        // $result = $query->getRow(); //gets the row as an object
        $result = $query->getRowArray(); //gets the row as an associative array
        if ($result != null) {
            return view('products/search', ['product' => $result]);
        } else {
            return "no records found";
        }
    }

    public function new()
    {
        // call form
        return view('products/new');
    }

    public function create()
    {
        // process new entry
        // $model = new ProductModel();
        // $model->save($this->request->getPost());
        // # $model->insert($this->request->getPost());
        // return redirect()->to('/products');

        $db = Database::connect();
        $sql = "insert into products (name,description,price) values (:name:,:description:,:price:)";
        $query = $db->query($sql, [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price')
        ]);

        if ($query) {
            return redirect()->to('/products');
        } else {
            return "something when wrong";
        }
    }

    public function edit($id = null)
    {
        // // call a view, with form data
        // // to identify record to edit, route params with the id
        // // find the record first
        // $model = new ProductModel();
        // $data = $model->find($id);

        // // pass the values to a form in a view
        // // return view('products/edit', ['data'=>$data]);
        // return view('products/edit', ['data' => $data]);

        $db = Database::connect();
        $sql = "select * from products where id = :id:";
        $query = $db->query($sql, ['id' => $id]);
        $result = $query->getRowArray();
        // $result = $db->query($sql,['id'=>$id])->getRowArray();
        return view('products/edit', ['data' => $result]);
    }

    public function update($id = null)
    {
        //process update
        // $model = new ProductModel();
        // $model->update($id, $this->request->getPost());
        // return redirect()->to('/products');

        $db = Database::connect();
        $sql = "update products set 
            name=:name:,
            description=:description:,
            price=:price: 
            where id=:id:
            ";
        $query = $db->query($sql, [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'price' => $this->request->getPost('price'),
            'id' => $id
        ]);
        return redirect()->to('/products');
    }

    public function delete($id = null)
    {
        // $model = new ProductModel();
        // $model->delete($id);
        // return redirect()->to('/products');

        $db = Database::connect();
        $sql = "delete from products where id=:id:";
        $query = $db->query($sql, ['id' => $id]);
        return redirect()->to('/products');
    }
}