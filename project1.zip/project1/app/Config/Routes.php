<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// static routes
$routes->get('/t1', 'Home::test1');
$routes->get('/t2', 'Home::test2');

// route parameters
$routes->get('/netpay/(:num)/(:num)', 'Home::netpay/$1/$2');

// :num, :alphanum, :any
$routes->get('/employee/(:alphanum)/(:alphanum)', 'Home::findme/$1/$2');


// demo routes
// $routes->get('/d', 'Demo::index');
// $routes->get('/d/p1', 'Demo::page1');
// $routes->get('/d/p2', 'Demo::page2');
// $routes->get('/d/register', 'Demo::myregister');
// $routes->post('/d/process', 'Demo::myprocess');

$routes->group('/d', function ($routes) {
    $routes->get('', 'Demo::index');
    $routes->get('p1', 'Demo::page1');
    $routes->get('p2', 'Demo::page2');
    $routes->get('register', 'Demo::myregister');
    $routes->post('process', 'Demo::myprocess');
});

$routes->group('/products', function ($routes) {
    $routes->get('', 'Product::index');
    $routes->get('(:num)', 'Product::show/$1');
    $routes->get('new', 'Product::new');
    $routes->post('create', 'Product::create');
    $routes->get('edit/(:num)', 'Product::edit/$1');
    $routes->post('update/(:num)', 'Product::update/$1');
    $routes->get('delete/(:num)', 'Product::delete/$1');
});