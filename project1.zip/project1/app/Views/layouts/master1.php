<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $this->renderSection('title') ?></title>
</head>

<body>

    <center>
        <h1>OSG PH SITE</h1>
        <nav>
            <a href="/d">Home</a>
            |<a href="/d/p1">Page1</a>
            |<a href="/d/p2">Page2</a>
            |<a href="/d/register">Register</a>

        </nav>
        <hr />
    </center>

    <?= $this->renderSection('body') ?>

</body>

</html>