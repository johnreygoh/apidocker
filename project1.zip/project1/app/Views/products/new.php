<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product New</title>
</head>

<body>

    Register a new Product<br />
    <form method="post" action="/products/create">
        name <input type="text" name="name" required> <br />
        description <br />
        <textarea name="description" required cols="30" rows="4"></textarea><br />
        price <input type="number" name="price" required><br />
        <input type="submit" name="submit" value="submit new product">

        <?= csrf_field() ?>

    </form>

</body>

</html>