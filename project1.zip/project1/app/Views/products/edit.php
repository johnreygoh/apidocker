<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Edit</title>
</head>

<body>

    <h1>Edit Product</h1>
    <form method="post" action="/products/update/<?= $data['id'] ?>">
        name <input type="text" name="name" value="<?= $data['name'] ?>" required> <br />
        description <br />
        <textarea name="description" required cols="30" rows="4"><?= $data['description'] ?></textarea><br />
        price <input type="number" name="price" value="<?= $data['price'] ?>" required><br />
        <input type="submit" name="submit" value="submit update">

        <?= csrf_field() ?>

    </form>

</body>

</html>