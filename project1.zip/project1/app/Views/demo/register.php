<?= $this->extend('layouts/master1') ?>

<?= $this->section('title') ?>
Demo-Register
<?= $this->endSection() ?>

<?= $this->section('body') ?>
Register new product<br />
<form method="post" action="/d/process">
    product name <input type="text" name="pname"><br />
    product description <br />
    <textarea name="pdescription" cols="30" rows="4"></textarea><br />
    product price <input type="number" name="pprice"> <br />
    <input type="submit" name="submit" value="submit">
</form>

<?= $this->endSection() ?>