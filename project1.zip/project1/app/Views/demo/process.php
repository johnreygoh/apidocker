<?= $this->extend('layouts/master1') ?>

<?= $this->section('title') ?>
Demo-Process
<?= $this->endSection() ?>

<?= $this->section('body') ?>

Product name: <b><?= $data["pname"] ?></b> <br />
Product description: <b><?= $data["pdescription"] ?></b> <br />
Product price: <b><?= $data["pprice"] ?></b> <br />

<?= $this->endSection() ?>