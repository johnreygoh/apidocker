<?= $this->extend('layouts/master1') ?>

<?= $this->section('title') ?>
Demo-Page2
<?= $this->endSection() ?>

<?= $this->section('body') ?>
This is the body of the Page 2.
<?= $this->endSection() ?>