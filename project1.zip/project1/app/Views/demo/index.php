<?= $this->extend('layouts/master1') ?>

<?= $this->section('title') ?>
Demo-Home
<?= $this->endSection() ?>

<?= $this->section('body') ?>
This is the body of the Home Page.
<?= $this->endSection() ?>