<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\API\ResponseTrait;

class ApiGatewayController extends BaseController
{
    use ResponseTrait;

    private function forwardRequest($url)
    {
        $client = \Config\Services::curlrequest();
        return $client->request(
            $this->request->getMethod(),
            $url,
            [
                'headers' => $this->request->getHeaders(),
                'form_params' => $this->request->getPost(),
                'http_errors' => false
            ]
        );
    }

    public function createUser()
    {
        $response = $this->forwardRequest('http://localhost:8081/user/create');
        return $this->respond(json_decode($response->getBody(), true), $response->getStatusCode());
    }

    public function getUser($id)
    {
        $response = $this->forwardRequest("http://localhost:8081/user/{$id}");
        return $this->respond(json_decode($response->getBody(), true), $response->getStatusCode());
    }

    public function createOrder()
    {
        $response = $this->forwardRequest('http://localhost:8082/order/create');
        return $this->respond(json_decode($response->getBody(), true), $response->getStatusCode());
    }

    public function getOrder($id)
    {
        $response = $this->forwardRequest("http://localhost:8082/order/{$id}");
        return $this->respond(json_decode($response->getBody(), true), $response->getStatusCode());
    }

    public function index()
    {
        //
    }
}