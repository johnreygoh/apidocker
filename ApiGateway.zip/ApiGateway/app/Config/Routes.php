<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/checkip', 'Home::checkip');


$routes->group('api', function ($routes) {
    $routes->post('user/create', 'ApiGatewayController::createUser');
    $routes->get('user/(:num)', 'ApiGatewayController::getUser/$1');
    $routes->post('order/create', 'ApiGatewayController::createOrder');
    $routes->get('order/(:num)', 'ApiGatewayController::getOrder/$1');
});