<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;
use App\Models\EmployeeModel;
use CodeIgniter\DataCaster\Cast\IntegerCast;


class Employees extends ResourceController
{

    protected $modelName = 'App\Models\EmployeeModel';
    protected $format = 'json';
    protected $model;

    public function __construct()
    {
        $model = new EmployeeModel();
    }

    // GET http://localhost:8080/employees
    public function index()
    {
        // return $this->respond($this->model->findAll());
        return $this->respond($this->model->getall());
    }

    // GET http://localhost:8080/employees/2
    public function show($id = null)
    {

        $rules = [
            'id' => 'required|numeric|less_than[4]',
        ];

        // no error
        if ($this->validateData(['id' => $id], $rules)) {
            $data = $this->model->findid($id);
            return $data ?
                $this->respond($data)
                : $this->failNotFound('Record not found');
        } else {
            return $this->validator->listErrors();
        }
    }


    // POST http://localhost:8080/employees
    public function create()
    {
        // filter and sanitize
        // filter individual post data
        // $data['name'] = $this->request->getPost('name', FILTER_SANITIZE_STRING);
        // $data['email'] = $this->request->getPost('email', FILTER_SANITIZE_EMAIL);

        $data = filter_var_array(
            $this->request->getPost(),
            [
                //'name' => FILTER_UNSAFE_RAW,
                'email' => FILTER_SANITIZE_EMAIL,
                'salary' => FILTER_SANITIZE_NUMBER_INT,
                'position' => FILTER_SANITIZE_STRING,
                'department' => FILTER_SANITIZE_STRING
            ]
        );

        //$data['name'] = htmlspecialchars($this->request->getPost('name'));
        $data['name'] = str_replace("'", "", strip_tags($this->request->getPost('name')));

        $rules = [
            'name' => 'required',
            'salary' => 'required|integer|greater_than[20000]',
        ];

        // $messages = [
        //     'name' => [
        //         'required' => 'no name',
        //         'alpha_numeric' => 'no symbols pls',
        //         'max_length[3]' => 'sobra sa 3 chars',
        //     ],
        //     'salary' => [
        //         'greater_than[20000]' => 'dapat more than 20000',
        //     ],

        // ];

        if ($this->validateData($data, $rules)) {
            if ($this->model->addemployee($data)) {
                return $this->respondCreated($data);
            }
            return $this->failValidationErrors($this->model->error());
        } else {
            return $this->validator->listErrors();
        }
    }



    // PUT http://localhost:8080/employees/2
    public function update($id = null)
    {
        $data = $this->request->getRawInput();

        $rules = [
            'salary' => 'greater_than[20000]',
        ];

        if ($this->validateData($data, $rules)) {
            if ($this->model->editemployee($id, $data)) {
                return $this->respondUpdated($data);
            }
            return $this->failNotFound('Record not found');
        } else {
            return $this->validator->listErrors();
        }
    }

    // DELETE http://localhost:8080/employees/1
    public function delete($id = null)
    {
        if ($this->model->deleteemployee($id)) {
            return $this->respondDeleted(['id' => $id, 'message' => 'Deleted']);
        }
        return $this->failNotFound();
    }
}