<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Employees Controller RESTFul endpoints
$routes->get('/employees', 'Employees::index');
$routes->post('/employees', 'Employees::create');
$routes->get('/employees/(:num)', 'Employees::show/$1');
$routes->put('/employees/(:num)', 'Employees::update/$1');
$routes->patch('/employees/(:num)', 'Employees::update/$1');
$routes->delete('/employees/(:num)', 'Employees::delete/$1');
//$routes->resource('employees'); //<----- controller name

// GET /employees   <---- getall
// GET /employees/1 <-- search
// POST /employees  <-- add
// PUT /employees/1 <-- edit
// PATCH /employees/1 <-- edit
// DELETE /employees/1 <-- edit