<?php

namespace App\Models;

use CodeIgniter\Model;
use Config\Database;

class EmployeeModel extends Model
{

    public function getall()
    {
        // return $this->findAll();

        $db = Database::connect();
        $sql = "Select * from employees";
        $query = $db->query($sql);
        $results = $query->getResultArray();
        return $results;
    }

    public function findid($id)
    {
        // return $this->find($id);
        $db = Database::connect();
        $sql = "select * from employees where id = :id:";
        $query = $db->query($sql, [
            'id' => $id
        ]);
        $result = $query->getRowArray();
        return $result;
    }

    public function addemployee($data)
    {
        // return $this->insert($data);
        $db = Database::connect();
        $sql = "insert into employees (name,position,department,email,salary) 
        values (:name:,:department:,:position:,:email:,:salary:)";
        $query = $db->query($sql, [
            'name' => $data['name'],
            'position' => $data['position'],
            'department' => $data['department'],
            'email' => $data['email'],
            'salary' => $data['salary'],
        ]);

        return $data;
    }

    public function editemployee($id, $data)
    {
        // $oldRecord['name']
        // $db = Database::connect();
        // $sql = "select * from employees where id = :id:";
        // $query = $db->query($sql, [
        //     'id' => $id
        // ]);
        // $result = $query->getRowArray();
        // // close database connection
        // $db->close();

        // fetch the old record
        $oldRecord = $this->findid($id);

        // return $this->update($id, $data);
        $db = Database::connect();
        $sql = "update employees set 
        name = :name:,
        position = :position:,
        department = :department:,
        email = :email:,
        salary = :salary:
        where id = :id:
        ";

        // x??y null coalescing
        $query = $db->query($sql, [
            'name' => $data['name'] ?? $oldRecord['name'],
            'position' => $data['position'] ?? $oldRecord['position'],
            'department' => $data['department'] ?? $oldRecord['department'],
            'email' => $data['email'] ?? $oldRecord['email'],
            'salary' => $data['salary'] ?? $oldRecord['salary'],
            'id' => $id
        ]);

        return $data;
    }

    public function deleteemployee($id)
    {
        try {
            $db = Database::connect();
            $sql = "delete from employees where id = :id:";
            $query = $db->query($sql, ['id' => $id]);
            $db->close();
            return true;
        } catch (\Throwable $th) {
            unset($db);
            return false;
        }
    }



    protected $table            = 'Employees';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name', 'department', 'position', 'email', 'salary'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];
}